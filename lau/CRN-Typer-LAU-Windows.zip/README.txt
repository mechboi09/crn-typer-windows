CRN Typer version 2

Four named option tabs, F1-F4 shortcuts, three initial CRN rows, Add CRN and Remove.
Paste list accepts spaces, commas and newlines; invalid/duplicate lists are rejected.
Normal: 200 ms. Fast: 1 ms requested. LAU additionally retains Instant single-batch mode.
AUB: up to 6 CRNs; final Tab Tab Enter targets Add to Summary.
LAU: up to 10 CRNs; Tabs only between inputs, then final Enter may submit immediately.
AUB and LAU are separate programs and save in separate locations.
Close other typers before starting so F1-F4 are available. Escape cancels except events already queued in Instant mode.
Settings autosave after 400ms of inactivity and when closing. CRNs, names, row count and speed restore on reopening.
Windows settings: %APPDATA%\CRNTyper-AUB\settings.xml or %APPDATA%\CRNTyper-LAU\settings.xml.
Settings are local, unencrypted files; do not put credentials in the CRN fields.
The app sends keyboard events; it cannot read the focused field or verify registration. Browser tab changes are not detected.
Test on the offline form. Live registration behavior has not been verified.